import 'package:flutter_test/flutter_test.dart';
import 'package:ai_nilam_smart/main.dart';

void main() {
  testWidgets('home screen shows app title and land tools', (tester) async {
    await tester.pumpWidget(const NilamApp());
    expect(find.text('AI Nilam Smart'), findsOneWidget);
    expect(find.text('நில அளவு கணிப்பான்'), findsOneWidget);
    expect(find.text('அலகு மாற்றி'), findsOneWidget);
  });
}

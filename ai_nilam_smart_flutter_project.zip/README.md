# AI Nilam Smart

Tamil/English Flutter starter for land measurement.

## Included in this starter
- Tamil-first home screen
- Rectangle/square area calculation
- Conversions: square feet, cent, ground (2,400 sq ft convention), acre and square metres
- Material 3 green theme
- Basic widget test and GitHub Actions CI workflow

## Run locally
1. Install Flutter stable and Android SDK.
2. Run `flutter create .` in this folder if platform folders are absent.
3. Run `flutter pub get`.
4. Run `flutter analyze`.
5. Run `flutter test`.
6. Run `flutter run`.

## Important
Patta/Chitta data access, FMB/official maps, offline MBTiles, PDF export, AI chat/voice,
authentication, cloud sync, analytics, ads and production security are not implemented yet.
Do not advertise these as available until implemented and tested.

Before Play Store release, confirm the final unique Android application ID, app icon,
screenshots, feature graphic, privacy policy, Data safety declarations, target API,
upload keystore and Play App Signing. Never commit keystore files or passwords.

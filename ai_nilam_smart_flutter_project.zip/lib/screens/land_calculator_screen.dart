import 'package:flutter/material.dart';

class LandCalculatorScreen extends StatefulWidget {
  const LandCalculatorScreen({super.key});
  @override
  State<LandCalculatorScreen> createState() => _LandCalculatorScreenState();
}

class _LandCalculatorScreenState extends State<LandCalculatorScreen> {
  final _length = TextEditingController();
  final _width = TextEditingController();
  double? _sqft;

  @override
  void dispose() {
    _length.dispose();
    _width.dispose();
    super.dispose();
  }

  void _calculate() {
    final length = double.tryParse(_length.text.trim());
    final width = double.tryParse(_width.text.trim());
    if (length == null || width == null || !length.isFinite || !width.isFinite || length <= 0 || width <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('சரியான நீளம் மற்றும் அகலத்தை உள்ளிடவும்')),
      );
      return;
    }
    setState(() => _sqft = length * width);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('நில அளவு கணிப்பான்')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('செவ்வக / சதுர நிலம்', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      TextField(controller: _length, keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'நீளம் (அடி)', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      TextField(controller: _width, keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'அகலம் (அடி)', border: OutlineInputBorder())),
      const SizedBox(height: 14),
      FilledButton(onPressed: _calculate, child: const Text('கணக்கிடு')),
      if (_sqft != null) ...[
        const SizedBox(height: 16),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${_sqft!.toStringAsFixed(2)} சதுர அடி',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const Divider(),
            _result('சென்ட்', _sqft! / 435.6, 4),
            _result('கிரவுண்ட்', _sqft! / 2400, 4),
            _result('ஏக்கர்', _sqft! / 43560, 5),
            _result('சதுர மீட்டர்', _sqft! / 10.7639104167, 3),
          ],
        ))),
      ],
    ]),
  );

  Widget _result(String label, double value, int digits) =>
      Padding(padding: const EdgeInsets.symmetric(vertical: 4),
        child: Text('$label: ${value.toStringAsFixed(digits)}'));
}

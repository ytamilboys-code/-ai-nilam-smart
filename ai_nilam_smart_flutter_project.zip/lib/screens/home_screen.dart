import 'package:flutter/material.dart';
import 'land_calculator_screen.dart';
import 'unit_converter_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <({String ta, String en, IconData icon, Widget page})>[
      (ta: 'நில அளவு கணிப்பான்', en: 'Land Calculator', icon: Icons.square_foot, page: const LandCalculatorScreen()),
      (ta: 'அலகு மாற்றி', en: 'Unit Converter', icon: Icons.swap_horiz, page: const UnitConverterScreen()),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('AI Nilam Smart'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('உங்கள் நிலத்திற்கு ஸ்மார்ட் உதவியாளர்',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Land tools for Tamil Nadu and India'),
          const SizedBox(height: 18),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.15),
            itemBuilder: (context, i) {
              final item = items[i];
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => item.page)),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(item.icon, size: 38, color: Theme.of(context).colorScheme.primary),
                      const SizedBox(height: 10),
                      Text(item.ta, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text(item.en, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
                    ]),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 20),
          const Text('குறிப்பு: கணக்கீடுகள் வழிகாட்டுதலுக்கானவை. சட்டப்பூர்வ நில உரிமைச் சான்றாகாது.',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
      ),
    );
  }
}

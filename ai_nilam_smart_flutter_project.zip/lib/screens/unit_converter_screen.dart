import 'package:flutter/material.dart';

class UnitConverterScreen extends StatefulWidget {
  const UnitConverterScreen({super.key});
  @override
  State<UnitConverterScreen> createState() => _UnitConverterScreenState();
}

class _UnitConverterScreenState extends State<UnitConverterScreen> {
  final _input = TextEditingController();
  String _unit = 'sqft';
  static const Map<String, double> _toSqft = {
    'sqft': 1, 'cent': 435.6, 'ground': 2400, 'acre': 43560, 'sqm': 10.7639104167,
  };
  static const Map<String, String> _labels = {
    'sqft': 'சதுர அடி', 'cent': 'சென்ட்', 'ground': 'கிரவுண்ட்',
    'acre': 'ஏக்கர்', 'sqm': 'சதுர மீட்டர்',
  };

  @override
  void dispose() { _input.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final amount = double.tryParse(_input.text.trim());
    final sqft = amount == null ? null : amount * _toSqft[_unit]!;
    return Scaffold(
      appBar: AppBar(title: const Text('நில அளவு அலகு மாற்றி')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        TextField(controller: _input,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'அளவை உள்ளிடவும்', border: OutlineInputBorder()),
          onChanged: (_) => setState(() {})),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: _unit,
          decoration: const InputDecoration(labelText: 'எந்த அலகிலிருந்து?', border: OutlineInputBorder()),
          items: _labels.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
          onChanged: (v) => setState(() => _unit = v ?? 'sqft'),
        ),
        const SizedBox(height: 18),
        if (sqft != null && sqft.isFinite && sqft >= 0)
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _toSqft.entries.map((e) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Text('${_labels[e.key]}: ${(sqft / e.value).toStringAsFixed(5)}'),
            )).toList(),
          ))),
      ]),
    );
  }
}

import 'package:flutter_test/flutter_test.dart';
import 'package:ai_nilam_smart/main.dart';

void main() {
  testWidgets('Home screen renders app title', (tester) async {
    await tester.pumpWidget(const NilamApp());
    expect(find.text('AI Nilam Smart'), findsOneWidget);
    expect(find.text('Land Calculator'), findsOneWidget);
  });
}
